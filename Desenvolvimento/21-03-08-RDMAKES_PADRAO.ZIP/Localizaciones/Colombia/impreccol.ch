#ifdef SPANISH
	#define STR0001 "Emisi�n de Recibos de Pago"
	#define STR0002 "Recibo de Pago"
	#define STR0003 "Recibo No."
	#define STR0004 "Periodo:"
	#define STR0005 "Pago:"
	#define STR0006 "Periodo de Pago:"
	#define STR0007 "Fecha de Pago:"
	#define STR0008 "Sucursal:"
	#define STR0009 "Matr�cula:"
	#define STR0010 "Nombre:"
	#define STR0011 "Tipo ID:"
	#define STR0012 "No. ID:"
	#define STR0013 "Funci�n:"
	#define STR0014 "Desc:"
	#define STR0015 "Cargo:"
	#define STR0016 "C.Costo:"
	#define STR0017 "Depto:"
	#define STR0018 "ARL:"
	#define STR0019 "EPS:"
	#define STR0020 "AFP:"
	#define STR0021 "CCF:"
	#define STR0022 "Banco Emp:"
	#define STR0023 "Banco CIA:"
	#define STR0024 "Sueldo:"
	#define STR0025 "Hrs. Men:"
	#define STR0026 "Grossup:"
	#define STR0027 "Devengos"
	#define STR0028 "Descuentos"
	#define STR0029 "Bases"
	#define STR0030 "Concepto"
	#define STR0031 "Hrs./D�a"
	#define STR0032 "Importes"
	#define STR0033 "Base"
	#define STR0034 "Total Devengos:"
	#define STR0035 "Total Descuentos:"
	#define STR0036 "Total Bases:"
	#define STR0037 "Neto Recibido (S/.):"
	#define STR0038 "Cuenta:"
	#define STR0039 "Recib� el valor anterior el __/__/___ ___________________________________________"
	#define STR0040 "Empleado"
	#define STR0041 "Banco:"
	#define STR0042 "Neto Recibido:"
	#define STR0043 "Cta.:"
	#define STR0044 "Recib� el valor anterior el ___/___/____"
	#define STR0045 "El servidor SMTP no est� cnfigurado "
	#define STR0046 "La cuenta de e-mail no est� configurada "
	#define STR0047 "La contrase�a del email no est� configurada "
	#define STR0048 "Errores ocurridos durante el env�o de los comprobantes de pago"
	#define STR0049 "Sr.(a)"
	#define STR0050 "Ocurrieron algunos errores durante el env�o del comprobante de pago por email, vea la siguiente lista:"
	#define STR0051 "Error durante el env�o del mensaje:"
	#define STR0052 "Falta de direcci�n de email registrado para el env�o:"
	#define STR0053 "Boleta de Remuneraciones - Saldos"
	#define STR0054 "Atentamente,"
	#define STR0055 "Selecionando Registros..."
	#define STR0056 "�Atenci�n!"
	#define STR0057 "No se localizaron comprobantes de pago disponibles para esta consulta."
	#define STR0058 "�CONTINUA!"
	#define STR0059 "Comprobante de pago"
	#define STR0060 "Se consigna en documento adjunto su comprobante de pago referente a"
#else
	#ifdef ENGLISH
		#define STR0001 "Emisi�n de Recibos de Pago"
		#define STR0002 "Recibo de Pago"
		#define STR0003 "Recibo No."
		#define STR0004 "Periodo:"
		#define STR0005 "Pago:"
		#define STR0006 "Periodo de Pago:"
		#define STR0007 "Fecha de Pago:"
		#define STR0008 "Sucursal:"
		#define STR0009 "Matr�cula:"
		#define STR0010 "Nombre:"
		#define STR0011 "Tipo ID:"
		#define STR0012 "No. ID:"
		#define STR0013 "Funci�n:"
		#define STR0014 "Desc:"
		#define STR0015 "Cargo:"
		#define STR0016 "C.Costo:"
		#define STR0017 "Depto:"
		#define STR0018 "ARL:"
		#define STR0019 "EPS:"
		#define STR0020 "AFP:"
		#define STR0021 "CCF:"
		#define STR0022 "Banco Emp:"
		#define STR0023 "Banco CIA:"
		#define STR0024 "Sueldo:"
		#define STR0025 "Hrs. Men:"
		#define STR0026 "Grossup:"
		#define STR0027 "Devengos"
		#define STR0028 "Descuentos"
		#define STR0029 "Bases"
		#define STR0030 "Concepto"
		#define STR0031 "Hrs./D�a"
		#define STR0032 "Importes"
		#define STR0033 "Base"
		#define STR0034 "Total Devengos:"
		#define STR0035 "Total Descuentos:"
		#define STR0036 "Total Bases:"
		#define STR0037 "Neto Recibido (S/.):"
		#define STR0038 "Cuenta:"
		#define STR0039 "Recib� el valor anterior el __/__/___ ___________________________________________"
		#define STR0040 "Empleado"
		#define STR0041 "Banco:"
		#define STR0042 "Neto Recibido:"
		#define STR0043 "Cta.:"
		#define STR0044 "Recib� el valor anterior el ___/___/____"
		#define STR0045 "El servidor SMTP no est� cnfigurado "
		#define STR0046 "La cuenta de e-mail no est� configurada "
		#define STR0047 "La contrase�a del email no est� configurada "
		#define STR0048 "Errores ocurridos durante el env�o de los comprobantes de pago"
		#define STR0049 "Sr.(a)"
		#define STR0050 "Ocurrieron algunos errores durante el env�o del comprobante de pago por email, vea la siguiente lista:"
		#define STR0051 "Error durante el env�o del mensaje:"
		#define STR0052 "Falta de direcci�n de email registrado para el env�o:"
		#define STR0053 "Boleta de Remuneraciones - Saldos"
		#define STR0054 "Atentamente,"
		#define STR0055 "Selecionando Registros..."
		#define STR0056 "�Atenci�n!"
		#define STR0057 "No se localizaron comprobantes de pago disponibles para esta consulta."
		#define STR0058 "�CONTINUA!"
		#define STR0059 "Comprobante de pago"
		#define STR0060 "Se consigna en documento adjunto su comprobante de pago referente a"
	#else
		#define STR0001 If( cPaisLoc $ "ANG|PTG", "Emisi�n de Recibos de Pago", "Emiss�o de Recibos de Pagamento" )
		#define STR0002 If( cPaisLoc $ "ANG|PTG", "Recibo de Pago", "Recibo de Pagamento" )
		#define STR0003 "Recibo No."
		#define STR0004 If( cPaisLoc $ "ANG|PTG", "Periodo:", "Per�odo:" )
		#define STR0005 If( cPaisLoc $ "ANG|PTG", "Pago:", "Pagamento:" )
		#define STR0006 If( cPaisLoc $ "ANG|PTG", "Periodo de Pago:", "Per�odo de Pagamento:" )
		#define STR0007 If( cPaisLoc $ "ANG|PTG", "Fecha de Pago:", "Data de Pagamento:" )
		#define STR0008 If( cPaisLoc $ "ANG|PTG", "Sucursal:", "Filial:" )
		#define STR0009 "Matr�cula:"
		#define STR0010 If( cPaisLoc $ "ANG|PTG", "Nombre:", "Nome" )
		#define STR0011 "Tipo ID:"
		#define STR0012 "No. ID:"
		#define STR0013 If( cPaisLoc $ "ANG|PTG", "Funci�n:", "Fun��o:" )
		#define STR0014 "Desc:"
		#define STR0015 "Cargo:"
		#define STR0016 If( cPaisLoc $ "ANG|PTG", "C.Costo:", "C.Custo:" )
		#define STR0017 "Depto:"
		#define STR0018 "ARL:"
		#define STR0019 "EPS:"
		#define STR0020 "AFP:"
		#define STR0021 "CCF:"
		#define STR0022 "Banco Emp:"
		#define STR0023 "Banco CIA:"
		#define STR0024 If( cPaisLoc $ "ANG|PTG", "Sueldo:", "Sal�rio:" )
		#define STR0025 "Hrs. Men:"
		#define STR0026 "Grossup:"
		#define STR0027 If( cPaisLoc $ "ANG|PTG", "Devengos", "Remunera��es" )
		#define STR0028 If( cPaisLoc $ "ANG|PTG", "Descuentos", "Descontos" )
		#define STR0029 "Bases"
		#define STR0030 If( cPaisLoc $ "ANG|PTG", "Concepto", "Verba" )
		#define STR0031 If( cPaisLoc $ "ANG|PTG", "Hrs./D�a", "Hrs./Dia" )
		#define STR0032 If( cPaisLoc $ "ANG|PTG", "Importes", "Valores" )
		#define STR0033 "Base"
		#define STR0034 If( cPaisLoc $ "ANG|PTG", "Total Devengos:", "Total Remunera��es:" )
		#define STR0035 If( cPaisLoc $ "ANG|PTG", "Total Descuentos:", "Total Descontos:" )
		#define STR0036 "Total Bases:"
		#define STR0037 If( cPaisLoc $ "ANG|PTG", "Neto Recibido (S/.):", "L�quido Recebido (S/.):" )
		#define STR0038 If( cPaisLoc $ "ANG|PTG", "Cuenta:", "Conta:" )
		#define STR0039 If( cPaisLoc $ "ANG|PTG", "Recib� el valor anterior el __/__/___ ___________________________________________", "Recebi o valor anterior em __/__/___ ___________________________________________" )
		#define STR0040 If( cPaisLoc $ "ANG|PTG", "Empleado", "Funcion�rio" )
		#define STR0041 "Banco:"
		#define STR0042 If( cPaisLoc $ "ANG|PTG", "Neto Recibido:", "L�quido Recebido:" )
		#define STR0043 "Cta.:"
		#define STR0044 If( cPaisLoc $ "ANG|PTG", "Recib� el valor anterior el ___/___/____", "Recebi o valor anterior em ___/___/____" )
		#define STR0045 If( cPaisLoc $ "ANG|PTG", "El servidor SMTP no est� cnfigurado ", "O servidor SMTP n�o est� configurado" )
		#define STR0046 If( cPaisLoc $ "ANG|PTG", "La cuenta de e-mail no est� configurada ", "A conta de e-mail n�o est� configurada" )
		#define STR0047 If( cPaisLoc $ "ANG|PTG", "La contrase�a del email no est� configurada ", "A senha do e-mail n�o est� configurada" )
		#define STR0048 If( cPaisLoc $ "ANG|PTG", "Errores ocurridos durante el env�o de los comprobantes de pago", "Erros ocorridos durante o envio dos recibos de pagamento" )
		#define STR0049 "Sr.(a)"
		#define STR0050 If( cPaisLoc $ "ANG|PTG", "Ocurrieron algunos errores durante el env�o del comprobante de pago por email, vea la siguiente lista:", "Ocorreram alguns erros durante o envio do recibo de pagamento por e-mail, veja a seguinte lista:" )
		#define STR0051 If( cPaisLoc $ "ANG|PTG", "Error durante el env�o del mensaje:", "Erro durante o envio da mensagem:" )
		#define STR0052 If( cPaisLoc $ "ANG|PTG", "Falta de direcci�n de email registrado para el env�o:", "Falta de endere�o do e-mail cadastrado para o envio:" )
		#define STR0053 If( cPaisLoc $ "ANG|PTG", "Boleta de Remuneraciones - Saldos", "Recibo de Remunera��es - Saldos" )
		#define STR0054 If( cPaisLoc $ "ANG|PTG", "Atentamente,", "Atenciosamente,," )
		#define STR0055 "Selecionando Registros..."
		#define STR0056 If( cPaisLoc $ "ANG|PTG", "�Atenci�n!", "Aten��o!" )
		#define STR0057 If( cPaisLoc $ "ANG|PTG", "No se localizaron comprobantes de pago disponibles para esta consulta.", "N�o foram localizados os recibos de pagamento dispon�veis para esta consulta." )
		#define STR0058 If( cPaisLoc $ "ANG|PTG", "�CONTINUA!", "PROSSEGUIR!" )
		#define STR0059 If( cPaisLoc $ "ANG|PTG", "Comprobante de pago", "Recibo de Pagamento" )
		#define STR0060 If( cPaisLoc $ "ANG|PTG", "Se consigna en documento adjunto su comprobante de pago referente a", "Consta em documento anexo seu recibo de pagamento referente a" )
	#endif
#endif
