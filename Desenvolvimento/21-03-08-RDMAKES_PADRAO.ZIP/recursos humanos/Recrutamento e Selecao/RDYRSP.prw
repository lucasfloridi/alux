#include "Totvs.Ch"
#define STR0001 "ATENCAO"
#define STR0002 "Este processo dever� ser executado por FILIAL."
#define STR0003 "Deseja transferir os registros de campo MEMO dos m�dulos Recrutamento & Sele��o e Terminal de Consulta (SIGARSP/SIGATCF) gravados na tabela SYP para a tabela RDY?"
#define STR0004 "Transferencia de registros realizada com sucesso!"
#define STR0005 "Transferindo registros do SYP para tabela RDY..."

User Function RDYRSP()

Private lMsErroAuto := .F.

If MsgYesNo( OemToAnsi( STR0002 + CRLF +  CRLF + STR0003), OemToAnsi( STR0001 ) )

    MsAguarde({|| MSExecAuto( {|| u_TransfReg() }) },OemToAnsi( STR0005 ) ) 

    If lMsErroAuto
        MostraErro()
    Else
        MsgInfo(OemToAnsi( STR0004 ), OemToAnsi( STR0001 ))
    EndIf
EndIf

Return !lMsErroAuto


User Function TransfReg()
Local aArea         := GetArea()
Local cAliasSYP     := GetNextAlias()
Local Ctab          := ""
Local lRet          := .T.
Local cFil          := xFilial('SYP')
Local cTmpFilTab    := ""
Local cTmpChave     := ""
Local lApaga        := .F. 
Local lSkip         := .F.
Local cPesqCpo      := "%("

cPesqCpo += " 'QL_ATIVIDA', "
cPesqCpo += " 'QR_MRESPOS', "
cPesqCpo += " 'QG_ANALISE', "
cPesqCpo += " 'QG_EXPER', "
cPesqCpo += " 'QO_CODMEM', "
cPesqCpo += " 'RT0_CODM', "
cPesqCpo += " 'RT1_CODM', "
cPesqCpo += " 'QS_CODPERF', "
cPesqCpo += " 'QD_CODOBSC', "
cPesqCpo += " 'QD_CODOBSA', "
cPesqCpo += " 'RAI_MRESPO', "
cPesqCpo += " 'RGK_CODCON', "
cPesqCpo += " 'RDG_CODMEM', "
cPesqCpo += " 'R8_CODMEMO', "
cPesqCpo += " 'RA_TCFMSG ' "

 cPesqCpo += ")%"
 
dbSelectArea('RDY')
dbSetOrder(1)

dbSelectArea('SYP')
dbSetOrder(1)

    BeginSql alias cAliasSYP
        SELECT * 
        FROM %table:SYP% SYP 
        WHERE SYP.YP_CAMPO IN %exp:cPesqCpo%  
        AND SYP.YP_FILIAL = %exp:cFil%
        AND SYP.%notDel%
    EndSql

    While ( cAliasSYP )->( !Eof() )  

        cTmpFilTab  := ""
        cTmpFilRDY  := (cAliasSYP)->YP_FILIAL
        cTmpChave   := (cAliasSYP)->YP_CHAVE
        cTmpCampo   := (cAliasSYP)->YP_CAMPO
        lApaga      := .F.
        lSkip       := .F.

        dbSelectArea('SX3')
        SX3->(dbSetOrder(2))
        If SX3->(dbSeek((cAliasSYP)->YP_CAMPO))
            cTab := SX3->X3_ARQUIVO
            (cTab)->(dbseek(xfilial(cTab))) // Para retornar xfilial() correto na MSMM
            cTmpFilTab := xFilial(cTab)

            //-Grava na RDY
       	    dbSelectArea("RDY")
    	    RDY->(dbSetOrder(2))
	        RDY->(dbGoTop())
	
	        If ! RDY->(dbSeek(cTmpFilTab + cTmpChave)) //Não grava se já tiver RDY_FILIAL gravado
		
	    	    RDY->(dbSetOrder(1))
	    	    RDY->(dbGoTop())
                lApaga := .T.
                
		        If ! RDY->(dbSeek( cTmpFilRDY + cTmpChave ))
						
			        While ! (cAliasSYP)->(EOF()) .AND. cTmpFilRDY == (cAliasSYP)->YP_FILIAL .AND. (cAliasSYP)->YP_CHAVE == cTmpChave 
                        
                        Reclock("RDY", .T.)
					    RDY->RDY_FILIAL := (cAliasSYP)->YP_FILIAL
					    RDY->RDY_CHAVE  := (cAliasSYP)->YP_CHAVE
					    RDY->RDY_TEXTO	:= (cAliasSYP)->YP_TEXTO
					    RDY->RDY_SEQ	:= (cAliasSYP)->YP_SEQ
					    RDY->RDY_CAMPO  := (cAliasSYP)->YP_CAMPO
					    RDY->RDY_FILTAB := cTmpFilTab
				        RDY->(MsUnlock())
				
				        (cAliasSYP)->(dbSkip())
                        lSkip := .T.
			        EndDo
			
			        dbSelectArea("RDY")
			        RDY->(dbSetOrder(2))
			        RDY->(dbGoTop())
			        RDY->(dbSeek(cTmpFilTab + cTmpChave))
		        Else
			    
                    // Se já existe o registro atualiza apenas o campo RDY_FILTAB
			        While RDY->( !EOF() .AND. cTmpFilRDY + cTmpChave == RDY_FILIAL + RDY_CHAVE )
				
				        Reclock("RDY", .F.)
					    RDY->RDY_FILTAB := cTmpFilTab
				        RDY->(MsUnlock())
				
				        RDY->(dbSkip())
			        EndDo
		        EndIf
	        EndIf

            //----------------------------
            If lApaga
                //Exclui registro na SYP
                MSMM(cTmpChave,,,,2,,,cTab,cTmpCampo,"SYP")
            EndIf
        EndIf    
        If !lSkip
            (cAliasSYP)->(DbSkip())
        EndIf   
    EndDo
    lRet    := .T.
       
    (cAliasSYP)->( dbCloseArea() )   
    
    RestArea(aArea)   
 
Return lRet
